# NeuralAI - Modern AI Company Landing Page

A sleek, high-performance landing page built with React, TypeScript, Tailwind CSS, and Three.js. Features an interactive particle background, smooth animations, and a dark theme optimized for AI/tech companies.

## 🚀 Features

- **Interactive Background**: Three.js particle system that reacts to mouse movements
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Dark Theme**: Modern dark aesthetic with electric accent colors
- **Smooth Animations**: Framer Motion powered micro-interactions and page transitions
- **SEO Optimized**: Complete meta tags, structured data, and accessibility features
- **Performance Focused**: Optimized for Core Web Vitals and fast loading

## 🎨 Design System

The project uses a comprehensive design system defined in `src/index.css` and `tailwind.config.ts`:

### Colors
- **Primary**: `#00E5FF` (Electric Blue)
- **Secondary**: `#9B5FFF` (Electric Purple) 
- **Background**: `#0B0F14` (Dark Blue)
- **Surface**: Various shades for cards and elevated content

### Components
All components use semantic design tokens instead of hardcoded colors:
- `.btn-electric` - Primary CTA buttons with glow effects
- `.btn-secondary` - Secondary buttons with purple accent
- `.btn-ghost` - Outline buttons for subtle actions
- `.card-glow` - Cards with hover effects and subtle shadows

## 🛠 Tech Stack

- **React 18** - Modern React with hooks and concurrent features
- **TypeScript** - Full type safety throughout the codebase
- **Tailwind CSS** - Utility-first styling with custom design tokens
- **Framer Motion** - Smooth animations and micro-interactions
- **Three.js + React Three Fiber** - Interactive 3D background effects
- **Vite** - Fast development and optimized production builds
- **Lucide Icons** - Beautiful, consistent iconography

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Layout.tsx      # Main layout wrapper
│   ├── Navbar.tsx      # Sticky navigation
│   ├── Hero.tsx        # Hero section with CTAs
│   ├── Features.tsx    # Feature grid
│   ├── UseCases.tsx    # Use cases with hover details
│   ├── Pricing.tsx     # Pricing tiers with toggle
│   ├── FAQ.tsx         # Accordion FAQ section
│   ├── Contact.tsx     # Contact form
│   ├── Footer.tsx      # Footer with newsletter signup
│   └── InteractiveBackground.tsx  # Three.js particle system
├── content/
│   └── site.ts         # All website content and copy
├── lib/
│   └── visualsConfig.ts # Interactive background configuration
└── pages/
    └── Index.tsx       # Main page component
```

## 🎛 Customization Guide

### Editing Content
All website content is centralized in `src/content/site.ts`. Update this file to change:
- Navigation links and labels
- Hero headline and copy
- Feature descriptions
- Pricing tiers and features
- FAQ questions and answers
- Contact form labels
- Footer content

### Customizing Colors and Design
1. **Primary Colors**: Edit CSS variables in `src/index.css`
2. **Component Styles**: Modify utility classes in `src/index.css`
3. **Tailwind Config**: Update `tailwind.config.ts` for additional design tokens

### Interactive Background Settings
Modify `src/lib/visualsConfig.ts` to adjust:
- Particle count and behavior
- Mouse interaction settings
- Gradient colors and effects
- Performance settings for mobile
- Animation parameters

Example configuration:
```typescript
export const visualsConfig = {
  particles: {
    count: 80,           // Number of particles
    colors: ['#00E5FF', '#9B5FFF', '#ffffff'],
  },
  mouse: {
    repelRadius: 150,    // Mouse repulsion distance
    repelStrength: 50,   // Repulsion intensity
  },
  // ... more settings
};
```

## 🚀 Development

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

3. **Build for Production**
   ```bash
   npm run build
   ```

4. **Preview Production Build**
   ```bash
   npm run preview
   ```

## 📱 Responsive Breakpoints

The design adapts across all screen sizes:
- **Mobile**: < 768px (simplified animations, reduced particles)
- **Tablet**: 768px - 1024px (optimized layout, touch-friendly)
- **Desktop**: > 1024px (full experience with all effects)

## ♿ Accessibility

- Semantic HTML structure with proper landmarks
- ARIA labels where appropriate
- Keyboard navigation support
- Focus indicators for all interactive elements
- Respects `prefers-reduced-motion` for users with vestibular disorders
- High contrast ratios meeting WCAG AA standards

## 🔧 Performance Optimizations

- **Lazy Loading**: Components and assets loaded on demand
- **Reduced Motion**: Simplified experience for users who prefer less motion
- **Mobile Optimization**: Fewer particles and simpler effects on mobile devices
- **Efficient Animations**: GPU-accelerated transforms and opacity changes
- **Bundle Optimization**: Tree-shaking and code splitting with Vite

## 📊 SEO & Analytics Ready

- Complete meta tags and Open Graph data
- Structured data for rich snippets
- Sitemap and robots.txt included
- Performance optimized for Core Web Vitals
- Analytics integration ready (add your tracking code)

## 🎯 Lighthouse Targets

The site is optimized to achieve:
- **Performance**: ≥ 90
- **Accessibility**: ≥ 95  
- **Best Practices**: ≥ 90
- **SEO**: ≥ 95

## 🔗 Deployment

The site is ready to deploy to any static hosting service:
- **Netlify**: Drag and drop the `dist` folder
- **Vercel**: Connect your Git repository
- **GitHub Pages**: Use the built-in Actions workflow
- **AWS S3**: Upload the `dist` folder to your bucket

## 📝 Content Guidelines

When editing content in `src/content/site.ts`:
- Keep headlines under 60 characters for SEO
- Write benefit-focused copy (what's in it for the user)
- Use active voice and action-oriented language
- Keep sentences under 18 words for readability
- Include relevant keywords naturally

## 🎨 Brand Customization

To adapt this template for your brand:
1. Update colors in the design system (`src/index.css`)
2. Replace content in `src/content/site.ts`
3. Add your logo and brand assets
4. Customize the particle colors in `visualsConfig.ts`
5. Update meta tags in `index.html`

## 🐛 Troubleshooting

**Performance Issues on Mobile**:
- Reduce particle count in `visualsConfig.ts`
- Set `enableOnMobile: false` to disable effects entirely

**Animation Issues**:
- Check if user has `prefers-reduced-motion` enabled
- Verify Framer Motion is properly installed

**Build Errors**:
- Ensure all TypeScript types are properly defined
- Check that all imports are using the correct paths

## 📄 License

This project is open source and available under the MIT License.

---

Built with ❤️ for the modern web. Perfect for AI companies, SaaS startups, and tech organizations looking to make a strong first impression.