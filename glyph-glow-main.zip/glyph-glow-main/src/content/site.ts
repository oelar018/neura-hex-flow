export const siteContent = {
  metadata: {
    title: "NeuralAI - Operational AI Built for Scale",
    description: "Transform your business operations with precision AI agents and intelligent automations. Deploy scalable AI solutions that drive real results.",
    url: "https://neurai.ai",
  },
  
  navigation: {
    logo: "NeuralAI",
    links: [
      { label: "Product", href: "#product" },
      { label: "Solutions", href: "#solutions" },
      { label: "Pricing", href: "#pricing" },
      { label: "Resources", href: "#resources" },
      { label: "Contact", href: "#contact" },
    ],
    cta: "Request a Demo",
  },

  hero: {
    headline: "Operational AI, Built for Scale",
    subheadline: "Transform complex business processes with precision AI agents that understand context, make decisions, and deliver measurable outcomes.",
    primaryCta: "Get Started",
    secondaryCta: "Request a Demo",
    trustBadges: [
      { name: "TechCorp", logo: "🏢" },
      { name: "InnovateLabs", logo: "🧪" },
      { name: "ScaleUp Inc", logo: "📈" },
      { name: "GlobalTech", logo: "🌐" },
      { name: "FutureSoft", logo: "💡" },
    ],
  },

  features: [
    {
      icon: "Brain",
      title: "Intelligent Automation",
      description: "Deploy AI agents that learn from your workflows and optimize operations in real-time.",
    },
    {
      icon: "Zap",
      title: "Lightning Fast Deploy",
      description: "Launch production-ready AI solutions in minutes, not months, with our plug-and-play platform.",
    },
    {
      icon: "Shield",
      title: "Enterprise Security",
      description: "Bank-grade security with SOC 2 compliance, end-to-end encryption, and audit trails.",
    },
    {
      icon: "BarChart3",
      title: "Advanced Analytics",
      description: "Real-time insights and performance metrics to measure AI impact on your business outcomes.",
    },
    {
      icon: "Cog",
      title: "Custom Integrations",
      description: "Seamlessly connect with your existing tools and workflows through 500+ pre-built integrations.",
    },
    {
      icon: "Users",
      title: "24/7 Expert Support",
      description: "Dedicated AI specialists and technical support to ensure your success at every step.",
    },
  ],

  useCases: [
    {
      title: "Customer Service Automation",
      description: "Intelligent agents that handle 85% of customer inquiries with human-like precision.",
      details: "Reduce response times by 70% while maintaining customer satisfaction scores above 4.8/5. Our AI agents understand context, sentiment, and urgency to provide personalized responses at scale.",
      metrics: "85% automation rate, 70% faster responses",
    },
    {
      title: "Supply Chain Optimization", 
      description: "Predictive AI that optimizes inventory, logistics, and demand forecasting in real-time.",
      details: "Cut operational costs by 30% through intelligent demand prediction, automated vendor management, and dynamic routing optimization. Perfect for retail, manufacturing, and e-commerce.",
      metrics: "30% cost reduction, 99.5% accuracy",
    },
    {
      title: "Financial Process Automation",
      description: "Streamline accounting, compliance, and risk assessment with precision AI workflows.",
      details: "Automate invoice processing, expense management, and regulatory reporting. Our AI ensures 99.9% accuracy while reducing processing time from hours to minutes.",
      metrics: "99.9% accuracy, 10x faster processing",
    },
    {
      title: "Sales Intelligence Platform",
      description: "AI-powered lead scoring, pipeline optimization, and revenue forecasting.",
      details: "Increase conversion rates by 45% with intelligent lead qualification, automated follow-ups, and predictive analytics that identify high-value opportunities before your competition.",
      metrics: "45% higher conversion, 60% more qualified leads",
    },
  ],

  testimonials: [
    {
      quote: "NeuralAI transformed our customer service operation. We're now handling 3x more inquiries with the same team size.",
      author: "Sarah Chen",
      title: "Head of Operations, TechCorp",
      rating: 5,
    },
    {
      quote: "The ROI was immediate. Within 30 days, we'd already saved more in operational costs than our annual subscription.",
      author: "Michael Rodriguez", 
      title: "CTO, InnovateLabs",
      rating: 5,
    },
    {
      quote: "Finally, an AI solution that actually delivers on its promises. The deployment was seamless.",
      author: "Emma Thompson",
      title: "Director of Digital Transformation, GlobalTech",
      rating: 5,
    },
  ],

  pricing: {
    toggle: {
      monthly: "Monthly",
      annual: "Annual",
      discount: "Save 20%",
    },
    tiers: [
      {
        name: "Starter",
        description: "Perfect for small teams getting started with AI automation",
        monthlyPrice: 299,
        annualPrice: 239,
        features: [
          "Up to 5 AI agents",
          "10,000 monthly operations",
          "Basic integrations",
          "Email support",
          "Standard analytics",
        ],
        cta: "Start Free Trial",
        popular: false,
      },
      {
        name: "Professional",
        description: "Ideal for growing businesses scaling their operations",
        monthlyPrice: 799,
        annualPrice: 639,
        features: [
          "Up to 25 AI agents",
          "100,000 monthly operations",
          "Advanced integrations",
          "Priority support",
          "Advanced analytics",
          "Custom workflows",
          "API access",
        ],
        cta: "Start Free Trial",
        popular: true,
      },
      {
        name: "Enterprise",
        description: "For large organizations requiring maximum scale and customization",
        monthlyPrice: "Custom",
        annualPrice: "Custom",
        features: [
          "Unlimited AI agents",
          "Unlimited operations", 
          "Custom integrations",
          "Dedicated success manager",
          "Enterprise analytics",
          "White-label options",
          "SLA guarantee",
          "On-premise deployment",
        ],
        cta: "Contact Sales",
        popular: false,
      },
    ],
  },

  faq: [
    {
      question: "How quickly can I deploy NeuralAI in my organization?",
      answer: "Most customers are up and running within 24-48 hours. Our plug-and-play architecture connects to your existing systems through pre-built integrations, and our onboarding team provides hands-on guidance to ensure smooth deployment.",
    },
    {
      question: "What kind of ROI can I expect from NeuralAI?",
      answer: "On average, our customers see 300-500% ROI within the first year. This comes from reduced operational costs, increased efficiency, and improved customer satisfaction. We provide detailed ROI projections during our consultation process.",
    },
    {
      question: "Is my data secure with NeuralAI?",
      answer: "Absolutely. We maintain SOC 2 Type II compliance, use end-to-end encryption, and offer on-premise deployment options. Your data never leaves your specified regions, and we provide complete audit trails for compliance requirements.",
    },
    {
      question: "Can NeuralAI integrate with my existing software stack?",
      answer: "Yes, we support 500+ pre-built integrations including Salesforce, HubSpot, Slack, Microsoft Office, Google Workspace, and most major enterprise software. We also provide custom API development for specialized systems.",
    },
    {
      question: "Do you offer training and support for my team?",
      answer: "Every customer receives comprehensive onboarding training, documentation access, and ongoing support. Professional and Enterprise plans include dedicated success managers and priority technical support.",
    },
    {
      question: "What happens if I need to scale up or down?",
      answer: "Our pricing scales with your usage, and you can upgrade or downgrade your plan at any time. Enterprise customers can adjust their agent limits and feature sets with flexible contract terms.",
    },
    {
      question: "How does NeuralAI compare to building AI solutions in-house?",
      answer: "Building AI capabilities in-house typically costs 10x more and takes 12-18 months. NeuralAI provides enterprise-grade AI infrastructure, pre-trained models, and ongoing updates, letting you focus on your core business instead of AI development.",
    },
    {
      question: "Can I try NeuralAI before committing to a plan?",
      answer: "Yes, we offer a 14-day free trial with full access to Professional features. No credit card required, and our team will help you set up relevant use cases during the trial period.",
    },
  ],

  contact: {
    title: "Ready to Transform Your Operations?",
    description: "Get a personalized demo and see how NeuralAI can revolutionize your business processes.",
    form: {
      name: "Full Name",
      email: "Work Email",
      company: "Company Name", 
      message: "Tell us about your use case",
      submit: "Request Demo",
    },
  },

  footer: {
    tagline: "Operational AI that delivers results.",
    social: [
      { name: "Twitter", href: "#", icon: "Twitter" },
      { name: "LinkedIn", href: "#", icon: "Linkedin" },
      { name: "GitHub", href: "#", icon: "Github" },
    ],
    links: [
      {
        title: "Product",
        items: [
          { label: "Features", href: "#features" },
          { label: "Integrations", href: "#integrations" },
          { label: "API Docs", href: "#docs" },
          { label: "Security", href: "#security" },
        ],
      },
      {
        title: "Resources",
        items: [
          { label: "Blog", href: "#blog" },
          { label: "Case Studies", href: "#cases" },
          { label: "Help Center", href: "#help" },
          { label: "Community", href: "#community" },
        ],
      },
      {
        title: "Company", 
        items: [
          { label: "About", href: "#about" },
          { label: "Careers", href: "#careers" },
          { label: "Press", href: "#press" },
          { label: "Contact", href: "#contact" },
        ],
      },
    ],
    newsletter: {
      title: "Stay Updated",
      description: "Get the latest AI insights and product updates.",
      placeholder: "Enter your email",
      button: "Subscribe",
    },
    legal: {
      copyright: "© 2024 NeuralAI. All rights reserved.",
      links: [
        { label: "Privacy Policy", href: "#privacy" },
        { label: "Terms of Service", href: "#terms" },
        { label: "Cookie Policy", href: "#cookies" },
      ],
    },
  },
};