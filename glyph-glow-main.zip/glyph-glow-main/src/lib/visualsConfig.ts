export const visualsConfig = {
  // Particle system configuration
  particles: {
    count: 80, // Number of particles (reduced for performance)
    size: {
      min: 1,
      max: 3,
    },
    speed: {
      min: 0.1,
      max: 0.3,
    },
    opacity: {
      min: 0.1,
      max: 0.6,
    },
    colors: [
      '#00E5FF', // Primary electric blue
      '#9B5FFF', // Secondary purple  
      '#ffffff', // White for variety
    ],
  },

  // Mouse interaction settings
  mouse: {
    repelRadius: 150, // Distance for particle repulsion
    repelStrength: 50, // Intensity of repulsion
    attractRadius: 80, // Distance for subtle attraction
    attractStrength: 10, // Intensity of attraction
  },

  // Gradient background settings
  gradient: {
    colors: [
      { color: '#00E5FF', opacity: 0.05, position: [0.2, 0.3] },
      { color: '#9B5FFF', opacity: 0.03, position: [0.8, 0.7] },
      { color: '#00E5FF', opacity: 0.02, position: [0.5, 0.9] },
    ],
    warpStrength: 0.3, // How much gradient warps toward mouse
    warpRadius: 200, // Distance for gradient warping
  },

  // Animation settings
  animation: {
    particleFloat: {
      amplitude: 2, // How much particles drift
      frequency: 0.001, // Speed of drift
    },
    gradientPulse: {
      amplitude: 0.2, // Pulse intensity
      frequency: 0.0005, // Pulse speed
    },
  },

  // Performance settings
  performance: {
    maxFps: 60,
    enableOnMobile: true, // Whether to show effects on mobile
    mobileParticleCount: 40, // Reduced particle count on mobile
    mobileSimplifiedGradient: true, // Simpler gradient on mobile
  },

  // Scroll parallax settings
  parallax: {
    intensity: 0.5, // Background scroll speed multiplier (0.5 = half speed)
    enableScrollWarp: true, // Whether scrolling affects gradient
  },

  // Accessibility
  accessibility: {
    respectReducedMotion: true, // Honor prefers-reduced-motion
    fallbackBackground: '#0B0F14', // Static background for reduced motion
    reducedParticleCount: 20, // Minimal particles for reduced motion
  },
};

export type VisualsConfig = typeof visualsConfig;