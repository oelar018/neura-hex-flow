export const hexagonConfig = {
  // Canvas and animation settings
  canvas: {
    backgroundColor: '#0B0F14', // Dark background
    pixelRatio: Math.min(window.devicePixelRatio || 1, 2), // Optimize for performance
  },

  // Hexagon grid configuration
  hexagon: {
    radius: 180, // Main hexagon radius (desktop)
    mobileRadius: 120, // Smaller radius for mobile
    layers: 3, // Number of concentric hexagon layers
    dotSize: {
      min: 1.5,
      max: 3.5,
      hovered: 5, // Size when hovered
    },
  },

  // Dot appearance
  dots: {
    baseColor: '#ffffff',
    glowColor: '#e5e7eb', // Light gray for glow effect
    accentColor: '#00E5FF', // Electric cyan for special effects
    opacity: {
      min: 0.2,
      max: 0.8,
      hovered: 1.0,
    },
    glowRadius: 8, // Blur radius for glow effect
  },

  // Animation parameters
  animation: {
    rotationSpeed: 0.0008, // Base rotation speed (radians per frame)
    pulseSpeed: 0.002, // Breathing/pulse animation speed
    pulseAmplitude: 0.3, // How much dots pulse in size
    floatAmplitude: 2, // Subtle floating movement
    transitionDuration: 300, // MS for hover transitions
  },

  // Mouse interaction
  mouse: {
    influenceRadius: 120, // Distance for mouse influence
    maxDisplacement: 15, // Maximum pixel displacement from mouse
    attractionStrength: 0.1, // How strongly dots move toward mouse
    glowInfluence: 80, // Radius for brightness increase
    enabled: true, // Can be disabled for reduced motion
  },

  // Mobile settings
  mobile: {
    autoRotate: true,
    rotationSpeed: 0.0003, // Slower auto-rotation on mobile
    reducedParticles: true, // Use fewer dots on mobile
    disableMouseEffects: true, // No hover effects on touch devices
    ambientPulse: true, // Gentle pulsing animation
  },

  // Performance settings
  performance: {
    maxDots: 61, // Updated for proper hexagon: 1 + 6 + 12 + 18 + 24 = 61 dots max (3 layers)
    targetFPS: 60,
    enableRAF: true, // Use requestAnimationFrame
    pauseWhenNotVisible: true, // Pause animation when tab is inactive
  },

  // Accessibility
  accessibility: {
    respectReducedMotion: true, // Honor prefers-reduced-motion
    reducedMotionFallback: {
      disableRotation: true,
      disableMouseEffects: true,
      staticDots: true, // Show static dots instead of animation
      reducedOpacity: 0.4,
    },
  },

  // Responsive breakpoints
  breakpoints: {
    mobile: 768,
    tablet: 1024,
  },
};

export type HexagonConfig = typeof hexagonConfig;

// Helper function to generate hexagon grid coordinates
export const generateHexagonGrid = (radius: number, layers: number) => {
  const dots: Array<{ x: number; y: number; layer: number; angle: number }> = [];
  
  // Center dot
  dots.push({ x: 0, y: 0, layer: 0, angle: 0 });
  
  for (let layer = 1; layer <= layers; layer++) {
    const layerRadius = radius * (layer / layers);
    
    // Create hexagon vertices for this layer
    for (let side = 0; side < 6; side++) {
      const dotsOnSide = layer;
      
      for (let i = 0; i < dotsOnSide; i++) {
        const t = i / Math.max(dotsOnSide - 1, 1); // Normalized position along side
        
        // Calculate start and end points of this hexagon side
        const startAngle = (side * Math.PI) / 3;
        const endAngle = ((side + 1) * Math.PI) / 3;
        
        const startX = Math.cos(startAngle) * layerRadius;
        const startY = Math.sin(startAngle) * layerRadius;
        const endX = Math.cos(endAngle) * layerRadius;
        const endY = Math.sin(endAngle) * layerRadius;
        
        // Interpolate between start and end points
        const x = startX + (endX - startX) * t;
        const y = startY + (endY - startY) * t;
        const angle = Math.atan2(y, x);
        
        // Avoid duplicating corner dots (except for the last side)
        if (i === dotsOnSide - 1 && side < 5) continue;
        
        dots.push({ x, y, layer, angle });
      }
    }
  }
  
  return dots;
};