import { motion } from 'framer-motion';
import { HexagonBackground } from './HexagonBackground';
import { Navbar } from './Navbar';
import { FullScreenHero } from './Hero';
import { Features } from './Features';
import { UseCases } from './UseCases';
import { Pricing } from './Pricing';
import { FAQ } from './FAQ';
import { Contact } from './Contact';
import { Footer } from './Footer';

export const Layout = () => {
  return (
    <div className="relative">
      {/* Hexagon Background - Full Screen Hero Only */}
      <div className="relative h-screen overflow-hidden">
        <HexagonBackground />
        <FullScreenHero />
      </div>
      
      {/* Rest of Content with Original Background */}
      <div className="relative">
        {/* Navbar for scrolled sections */}
        <Navbar />
        
        <motion.main
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="bg-background"
        >
          <Features />
          <UseCases />
          <Pricing />
          <FAQ />
          <Contact />
        </motion.main>
        
        <Footer />
      </div>
    </div>
  );
};