import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export const FullScreenHero = () => {
  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToNext = () => {
    const element = document.querySelector('#product');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative h-screen w-full flex flex-col justify-between overflow-hidden">
      {/* Navigation Header */}
      <motion.header 
        className="relative z-20 flex items-center justify-between p-6 md:p-8"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
      >
        {/* Logo */}
        <motion.div 
          className="text-2xl font-bold text-white"
          whileHover={{ scale: 1.05 }}
          transition={{ type: 'spring', stiffness: 300 }}
        >
          YourAI
        </motion.div>

        {/* Contact Button */}
        <motion.button
          onClick={scrollToContact}
          className="px-6 py-3 border-2 border-white/20 text-white rounded-full hover:border-white/40 hover:bg-white/5 transition-all duration-300 backdrop-blur-sm"
          whileHover={{ 
            scale: 1.05,
            boxShadow: '0 0 20px rgba(255, 255, 255, 0.2)',
          }}
          whileTap={{ scale: 0.95 }}
        >
          Contact Us
        </motion.button>
      </motion.header>

      {/* Main Content */}
      <div className="relative z-20 flex-1 flex items-center justify-center px-6 md:px-8">
        <div className="text-center max-w-4xl">
          <motion.h1 
            className="text-6xl md:text-8xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
          >
            AI, <span className="text-primary">Simplified</span>.
          </motion.h1>

          <motion.p 
            className="text-xl md:text-2xl text-white/80 mb-12 leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
          >
            Transforming data into decisions at scale.
          </motion.p>

          <motion.button
            onClick={scrollToNext}
            className="group inline-flex items-center gap-3 px-8 py-4 bg-primary text-black rounded-full font-semibold text-lg hover:scale-105 transition-all duration-300"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            whileHover={{ 
              boxShadow: '0 0 40px rgba(0, 229, 255, 0.5)',
            }}
            whileTap={{ scale: 0.95 }}
          >
            Get Started
            <ArrowRight 
              size={20} 
              className="group-hover:translate-x-1 transition-transform duration-200" 
            />
          </motion.button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="relative z-20 flex justify-center pb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1.5 }}
      >
        <motion.div
          className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center cursor-pointer"
          onClick={scrollToNext}
          animate={{ 
            boxShadow: [
              '0 0 0 0 rgba(255, 255, 255, 0.7)',
              '0 0 0 10px rgba(255, 255, 255, 0)',
              '0 0 0 0 rgba(255, 255, 255, 0)',
            ]
          }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeOut' }}
          whileHover={{ scale: 1.1 }}
        >
          <motion.div
            className="w-1 h-3 bg-white/60 rounded-full mt-2"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          />
        </motion.div>
      </motion.div>
    </section>
  );
};