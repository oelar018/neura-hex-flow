import { useRef, useEffect, useState, useCallback } from 'react';
import { hexagonConfig, generateHexagonGrid } from '@/lib/hexagonConfig';

interface Dot {
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  layer: number;
  angle: number;
  size: number;
  opacity: number;
  targetOpacity: number;
  hovered: boolean;
}

export const HexagonBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const mouseRef = useRef({ x: 0, y: 0 });
  const dotsRef = useRef<Dot[]>([]);
  const timeRef = useRef(0);
  const [isVisible, setIsVisible] = useState(true);

  // Check for reduced motion preference
  const prefersReducedMotion = typeof window !== 'undefined' 
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches 
    : false;

  // Check if mobile device
  const isMobile = typeof window !== 'undefined' 
    ? window.innerWidth < hexagonConfig.breakpoints.mobile 
    : false;

  // Initialize dots
  const initializeDots = useCallback((canvasWidth: number, canvasHeight: number) => {
    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;
    const radius = isMobile ? hexagonConfig.hexagon.mobileRadius : hexagonConfig.hexagon.radius;
    
    const gridDots = generateHexagonGrid(radius, hexagonConfig.hexagon.layers);
    
    dotsRef.current = gridDots.map((dot) => ({
      ...dot,
      x: centerX + dot.x,
      y: centerY + dot.y,
      baseX: centerX + dot.x,
      baseY: centerY + dot.y,
      size: Math.random() * (hexagonConfig.hexagon.dotSize.max - hexagonConfig.hexagon.dotSize.min) + hexagonConfig.hexagon.dotSize.min,
      opacity: Math.random() * (hexagonConfig.dots.opacity.max - hexagonConfig.dots.opacity.min) + hexagonConfig.dots.opacity.min,
      targetOpacity: Math.random() * (hexagonConfig.dots.opacity.max - hexagonConfig.dots.opacity.min) + hexagonConfig.dots.opacity.min,
      hovered: false,
    }));
  }, [isMobile]);

  // Animation loop
  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || !isVisible) return;

    timeRef.current += 1;
    
    // Clear canvas
    ctx.fillStyle = hexagonConfig.canvas.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Update and draw dots
    dotsRef.current.forEach((dot) => {
      // Base rotation animation (if not reduced motion)
      if (!prefersReducedMotion || !hexagonConfig.accessibility.respectReducedMotion) {
        const rotationSpeed = isMobile && hexagonConfig.mobile.autoRotate 
          ? hexagonConfig.mobile.rotationSpeed 
          : hexagonConfig.animation.rotationSpeed;
          
        const rotation = timeRef.current * rotationSpeed;
        const rotatedX = Math.cos(dot.angle + rotation) * Math.sqrt(Math.pow(dot.baseX - canvas.width/2, 2) + Math.pow(dot.baseY - canvas.height/2, 2));
        const rotatedY = Math.sin(dot.angle + rotation) * Math.sqrt(Math.pow(dot.baseX - canvas.width/2, 2) + Math.pow(dot.baseY - canvas.height/2, 2));
        
        dot.x = canvas.width/2 + rotatedX + Math.sin(timeRef.current * hexagonConfig.animation.pulseSpeed + dot.layer) * hexagonConfig.animation.floatAmplitude;
        dot.y = canvas.height/2 + rotatedY + Math.cos(timeRef.current * hexagonConfig.animation.pulseSpeed + dot.layer) * hexagonConfig.animation.floatAmplitude;
      }

      // Mouse influence (desktop only)
      if (!isMobile && hexagonConfig.mouse.enabled && !prefersReducedMotion) {
        const mouseDistance = Math.sqrt(
          Math.pow(dot.x - mouseRef.current.x, 2) + 
          Math.pow(dot.y - mouseRef.current.y, 2)
        );
        
        if (mouseDistance < hexagonConfig.mouse.influenceRadius) {
          const influence = (hexagonConfig.mouse.influenceRadius - mouseDistance) / hexagonConfig.mouse.influenceRadius;
          const angle = Math.atan2(mouseRef.current.y - dot.y, mouseRef.current.x - dot.x);
          
          dot.x += Math.cos(angle) * influence * hexagonConfig.mouse.maxDisplacement * hexagonConfig.mouse.attractionStrength;
          dot.y += Math.sin(angle) * influence * hexagonConfig.mouse.maxDisplacement * hexagonConfig.mouse.attractionStrength;
          
          // Increase opacity near mouse
          if (mouseDistance < hexagonConfig.mouse.glowInfluence) {
            dot.targetOpacity = hexagonConfig.dots.opacity.hovered;
            dot.hovered = true;
          } else {
            dot.targetOpacity = dot.layer === 0 ? hexagonConfig.dots.opacity.max : hexagonConfig.dots.opacity.min + Math.random() * 0.3;
            dot.hovered = false;
          }
        } else {
          dot.targetOpacity = dot.layer === 0 ? hexagonConfig.dots.opacity.max : hexagonConfig.dots.opacity.min + Math.random() * 0.3;
          dot.hovered = false;
        }
      }

      // Smooth opacity transitions
      dot.opacity += (dot.targetOpacity - dot.opacity) * 0.05;

      // Pulse animation
      const pulseScale = 1 + Math.sin(timeRef.current * hexagonConfig.animation.pulseSpeed + dot.layer) * hexagonConfig.animation.pulseAmplitude * 0.1;
      const currentSize = dot.size * pulseScale * (dot.hovered ? 1.4 : 1);

      // Draw dot with glow effect
      if (currentSize > 0 && dot.opacity > 0.01) {
        // Outer glow
        const gradient = ctx.createRadialGradient(dot.x, dot.y, 0, dot.x, dot.y, hexagonConfig.dots.glowRadius);
        gradient.addColorStop(0, `rgba(255, 255, 255, ${dot.opacity})`);
        gradient.addColorStop(0.5, `rgba(229, 231, 235, ${dot.opacity * 0.5})`);
        gradient.addColorStop(1, `rgba(229, 231, 235, 0)`);
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(dot.x, dot.y, hexagonConfig.dots.glowRadius, 0, Math.PI * 2);
        ctx.fill();

        // Core dot
        ctx.fillStyle = dot.hovered 
          ? hexagonConfig.dots.accentColor 
          : `rgba(255, 255, 255, ${dot.opacity})`;
        ctx.beginPath();
        ctx.arc(dot.x, dot.y, currentSize, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    if (isVisible) {
      animationRef.current = requestAnimationFrame(animate);
    }
  }, [isMobile, isVisible, prefersReducedMotion]);

  // Mouse move handler
  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (isMobile || !hexagonConfig.mouse.enabled) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    mouseRef.current = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
  }, [isMobile]);

  // Setup canvas and start animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const updateCanvasSize = () => {
      const pixelRatio = hexagonConfig.canvas.pixelRatio;
      canvas.width = window.innerWidth * pixelRatio;
      canvas.height = window.innerHeight * pixelRatio;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(pixelRatio, pixelRatio);
      
      // Reinitialize dots with new canvas size
      initializeDots(window.innerWidth, window.innerHeight);
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    // Mouse events
    if (!isMobile) {
      canvas.addEventListener('mousemove', handleMouseMove);
    }

    // Visibility API for performance
    const handleVisibilityChange = () => {
      setIsVisible(!document.hidden);
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Start animation
    animate();

    return () => {
      window.removeEventListener('resize', updateCanvasSize);
      if (!isMobile) {
        canvas.removeEventListener('mousemove', handleMouseMove);
      }
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [animate, handleMouseMove, initializeDots, isMobile]);

  // Render fallback for reduced motion
  if (prefersReducedMotion && hexagonConfig.accessibility.respectReducedMotion) {
    return (
      <div 
        className="fixed inset-0 z-0 bg-[#0B0F14]"
        style={{
          background: `
            radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.1) 1px, transparent 1px),
            #0B0F14
          `,
          backgroundSize: '40px 40px',
          opacity: hexagonConfig.accessibility.reducedMotionFallback.reducedOpacity,
        }}
      />
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0"
      style={{ 
        background: hexagonConfig.canvas.backgroundColor,
        touchAction: 'none',
      }}
    />
  );
};