import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { siteContent } from '@/content/site';

export const Features = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6 }
    },
  };

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName];
    return Icon || LucideIcons.Zap;
  };

  return (
    <section id="product" className="py-24 px-4 relative">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Powerful AI That <span className="text-primary">Just Works</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Deploy intelligent automation that learns from your workflows and optimizes 
            business processes with unprecedented precision and speed.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {siteContent.features.map((feature, index) => {
            const Icon = getIcon(feature.icon);
            
            return (
              <motion.div
                key={feature.title}
                variants={itemVariants}
                className="card-glow p-8 group"
                whileHover={{ y: -8 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              >
                <div className="mb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                    <Icon 
                      size={32} 
                      className="text-primary group-hover:scale-110 transition-transform duration-300" 
                    />
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors duration-300">
                    {feature.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                <motion.div 
                  className="h-1 bg-gradient-to-r from-primary/0 via-primary/50 to-primary/0 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"
                />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Background decoration */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/5 rounded-full blur-3xl -z-10" />
      </div>
    </section>
  );
};