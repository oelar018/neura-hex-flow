import { useRef, useEffect, useState, useCallback } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { visualsConfig } from '@/lib/visualsConfig';

interface Particle {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  originalPosition: THREE.Vector3;
  color: string;
  opacity: number;
}

const Particles = ({ mousePosition }: { mousePosition: { x: number; y: number } }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const [particles, setParticles] = useState<Particle[]>([]);
  
  // Initialize particles
  useEffect(() => {
    const count = window.innerWidth < 768 
      ? visualsConfig.performance.mobileParticleCount 
      : visualsConfig.particles.count;
    
    const newParticles: Particle[] = [];
    
    for (let i = 0; i < count; i++) {
      const x = (Math.random() - 0.5) * 10;
      const y = (Math.random() - 0.5) * 10;
      const z = (Math.random() - 0.5) * 5;
      
      const position = new THREE.Vector3(x, y, z);
      const originalPosition = position.clone();
      const velocity = new THREE.Vector3(
        (Math.random() - 0.5) * visualsConfig.particles.speed.max,
        (Math.random() - 0.5) * visualsConfig.particles.speed.max,
        0
      );
      
      const color = visualsConfig.particles.colors[
        Math.floor(Math.random() * visualsConfig.particles.colors.length)
      ];
      
      const opacity = THREE.MathUtils.lerp(
        visualsConfig.particles.opacity.min,
        visualsConfig.particles.opacity.max,
        Math.random()
      );

      newParticles.push({
        position,
        velocity,
        originalPosition,
        color,
        opacity,
      });
    }
    
    setParticles(newParticles);
  }, []);

  // Animation loop
  useFrame((state) => {
    if (!pointsRef.current || particles.length === 0) return;

    const time = state.clock.getElapsedTime();
    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
    const colors = pointsRef.current.geometry.attributes.color.array as Float32Array;

    particles.forEach((particle, i) => {
      const i3 = i * 3;

      // Mouse repulsion effect
      const mouseWorldX = (mousePosition.x / window.innerWidth) * 10 - 5;
      const mouseWorldY = -(mousePosition.y / window.innerHeight) * 10 + 5;
      
      const distanceToMouse = Math.sqrt(
        Math.pow(particle.position.x - mouseWorldX, 2) +
        Math.pow(particle.position.y - mouseWorldY, 2)
      );
      
      const repelRadius = visualsConfig.mouse.repelRadius * 0.01;
      
      if (distanceToMouse < repelRadius) {
        const repelStrength = (1 - distanceToMouse / repelRadius) * visualsConfig.mouse.repelStrength * 0.001;
        const angle = Math.atan2(
          particle.position.y - mouseWorldY,
          particle.position.x - mouseWorldX
        );
        
        particle.velocity.x += Math.cos(angle) * repelStrength;
        particle.velocity.y += Math.sin(angle) * repelStrength;
      }

      // Floating animation
      const floatX = Math.sin(time * visualsConfig.animation.particleFloat.frequency + i) * 
                    visualsConfig.animation.particleFloat.amplitude * 0.1;
      const floatY = Math.cos(time * visualsConfig.animation.particleFloat.frequency + i * 2) * 
                    visualsConfig.animation.particleFloat.amplitude * 0.1;

      // Update position with velocity and floating
      particle.position.add(particle.velocity);
      particle.position.x += floatX * 0.01;
      particle.position.y += floatY * 0.01;

      // Restore to original position gradually
      particle.position.lerp(particle.originalPosition, 0.005);

      // Apply damping to velocity
      particle.velocity.multiplyScalar(0.98);

      // Wrap around screen bounds
      if (particle.position.x > 5) particle.position.x = -5;
      if (particle.position.x < -5) particle.position.x = 5;
      if (particle.position.y > 5) particle.position.y = -5;
      if (particle.position.y < -5) particle.position.y = 5;

      // Update geometry
      positions[i3] = particle.position.x;
      positions[i3 + 1] = particle.position.y;
      positions[i3 + 2] = particle.position.z;

      // Update colors with opacity variation
      const color = new THREE.Color(particle.color);
      const opacityVariation = Math.sin(time * 2 + i) * 0.1 + 0.9;
      const finalOpacity = particle.opacity * opacityVariation;
      
      colors[i3] = color.r * finalOpacity;
      colors[i3 + 1] = color.g * finalOpacity;
      colors[i3 + 2] = color.b * finalOpacity;
    });

    pointsRef.current.geometry.attributes.position.needsUpdate = true;
    pointsRef.current.geometry.attributes.color.needsUpdate = true;
  });

  // Create geometry
  const positions = new Float32Array(particles.length * 3);
  const colors = new Float32Array(particles.length * 3);
  
  particles.forEach((particle, i) => {
    const i3 = i * 3;
    positions[i3] = particle.position.x;
    positions[i3 + 1] = particle.position.y;
    positions[i3 + 2] = particle.position.z;
    
    const color = new THREE.Color(particle.color);
    colors[i3] = color.r * particle.opacity;
    colors[i3 + 1] = color.g * particle.opacity;
    colors[i3 + 2] = color.b * particle.opacity;
  });

  return (
    <Points ref={pointsRef} positions={positions}>
      <PointMaterial
        transparent
        vertexColors
        size={visualsConfig.particles.size.max}
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
};

export const InteractiveBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);

  // Mouse tracking
  const handleMouseMove = useCallback((event: MouseEvent) => {
    setMousePosition({
      x: event.clientX,
      y: event.clientY,
    });
  }, []);

  // Scroll tracking for parallax
  const handleScroll = useCallback(() => {
    setScrollY(window.scrollY);
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [handleMouseMove, handleScroll]);

  // Check for reduced motion preference
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  if (prefersReducedMotion && visualsConfig.accessibility.respectReducedMotion) {
    return (
      <div 
        className="fixed inset-0 pointer-events-none z-0"
        style={{ 
          background: `linear-gradient(135deg, ${visualsConfig.accessibility.fallbackBackground} 0%, #1a1a2e 100%)`,
          transform: `translateY(${scrollY * visualsConfig.parallax.intensity}px)`,
        }}
      />
    );
  }

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Gradient Background */}
      <div 
        className="absolute inset-0 bg-gradient-nebula opacity-30"
        style={{
          transform: `translateY(${scrollY * visualsConfig.parallax.intensity}px)`,
          background: `
            radial-gradient(circle at ${mousePosition.x * 0.1}% ${mousePosition.y * 0.1}%, hsl(187 100% 50% / 0.05) 0%, transparent 50%),
            radial-gradient(circle at 20% 80%, hsl(263 77% 68% / 0.03) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, hsl(187 100% 50% / 0.02) 0%, transparent 50%)
          `,
        }}
      />
      
      {/* Three.js Particle System */}
      <Canvas
        ref={canvasRef}
        className="absolute inset-0"
        style={{
          transform: `translateY(${scrollY * visualsConfig.parallax.intensity}px)`,
        }}
        camera={{ position: [0, 0, 5], fov: 75 }}
        gl={{ alpha: true, antialias: false }}
        performance={{ min: 0.5 }}
      >
        <Particles mousePosition={mousePosition} />
      </Canvas>
    </div>
  );
};