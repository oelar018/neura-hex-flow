import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Sparkles, ArrowRight } from 'lucide-react';
import { siteContent } from '@/content/site';

export const Pricing = () => {
  const [isAnnual, setIsAnnual] = useState(false);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6 }
    },
  };

  const formatPrice = (tier: typeof siteContent.pricing.tiers[0]) => {
    if (typeof tier.monthlyPrice === 'string') return tier.monthlyPrice;
    
    const price = isAnnual ? tier.annualPrice : tier.monthlyPrice;
    return typeof price === 'string' ? price : `$${price}`;
  };

  return (
    <section id="pricing" className="py-24 px-4 relative">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Simple, <span className="text-primary">Transparent Pricing</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
            Choose the perfect plan for your business needs. Start with a free trial, 
            scale as you grow, and unlock enterprise features when you're ready.
          </p>

          {/* Billing Toggle */}
          <motion.div 
            className="inline-flex items-center bg-surface rounded-2xl p-2 mb-12"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                !isAnnual 
                  ? 'bg-primary text-primary-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {siteContent.pricing.toggle.monthly}
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 relative ${
                isAnnual 
                  ? 'bg-primary text-primary-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {siteContent.pricing.toggle.annual}
              <span className="absolute -top-2 -right-2 bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded-full">
                {siteContent.pricing.toggle.discount}
              </span>
            </button>
          </motion.div>
        </motion.div>

        {/* Pricing Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto"
        >
          {siteContent.pricing.tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              variants={cardVariants}
              className={`relative card-glow p-8 ${
                tier.popular 
                  ? 'ring-2 ring-primary/50 transform scale-105' 
                  : ''
              }`}
              whileHover={{ 
                y: tier.popular ? -12 : -8,
                scale: tier.popular ? 1.08 : 1.02 
              }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            >
              {/* Popular Badge */}
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-primary text-primary-foreground px-6 py-2 rounded-full text-sm font-semibold flex items-center gap-2">
                    <Sparkles size={16} />
                    Most Popular
                  </div>
                </div>
              )}

              {/* Header */}
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                <p className="text-muted-foreground mb-6">{tier.description}</p>
                
                <div className="mb-2">
                  <span className="text-4xl font-bold">
                    {formatPrice(tier)}
                  </span>
                  {typeof tier.monthlyPrice === 'number' && (
                    <span className="text-muted-foreground">
                      /{isAnnual ? 'year' : 'month'}
                    </span>
                  )}
                </div>
                
                {isAnnual && typeof tier.monthlyPrice === 'number' && (
                  <p className="text-sm text-muted-foreground">
                    Billed annually
                  </p>
                )}
              </div>

              {/* Features */}
              <ul className="space-y-4 mb-8">
                {tier.features.map((feature, featureIndex) => (
                  <motion.li
                    key={featureIndex}
                    className="flex items-start gap-3"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: featureIndex * 0.1 }}
                  >
                    <Check 
                      size={20} 
                      className="text-primary mt-0.5 flex-shrink-0" 
                    />
                    <span className="text-sm">{feature}</span>
                  </motion.li>
                ))}
              </ul>

              {/* CTA Button */}
              <motion.button
                className={`w-full py-4 rounded-xl font-semibold transition-all duration-300 ${
                  tier.popular
                    ? 'btn-electric'
                    : 'btn-ghost'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <span className="flex items-center justify-center gap-2">
                  {tier.cta}
                  <ArrowRight size={18} />
                </span>
              </motion.button>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center mt-16"
        >
          <p className="text-muted-foreground mb-6">
            Need a custom solution? Our enterprise team is here to help.
          </p>
          <motion.button
            className="btn-ghost"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Talk to Sales
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};